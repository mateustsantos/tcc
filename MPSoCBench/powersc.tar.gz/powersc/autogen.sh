echo Running aclocal
aclocal
echo Running autoheader
autoheader
echo Running automake
automake -ac
echo Running autoconf
autoconf
