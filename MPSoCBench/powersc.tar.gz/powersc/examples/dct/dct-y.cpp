#include "dct-y.h"
IMPL_RAM(1024, yram);
