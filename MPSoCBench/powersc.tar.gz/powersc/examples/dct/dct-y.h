#ifndef DCT_Y_H
#define DCT_Y_H
#include <systemc.h>
#include "ram.h"
DEFINE_RAM(32, sc_uint<32>, sc_uint<5>, yram);
#endif
