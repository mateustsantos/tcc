#ifndef DIRETORIO_H
#define DIRETORIO_H
#include "cacheMem.h"
#include "common.h"

class Diretorio
{
	public:
		fstream log;
		int totalOfCaches;
		int nWay;
		cacheMem** cacheMemVector;
		Diretorio();
		virtual ~Diretorio();
		void add(int);
		bool checkValidation(int, uint32_t);
		bool validate(int, uint32_t);
		bool unvalidate(int, uint32_t);

	protected:
	private:
};

#endif // DIRETORIO_H
