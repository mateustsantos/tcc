#ifndef CACHEMEMORYLIST_H
#define CACHEMEMORYLIST_H
#include "cacheLine.h"

class cacheMem
{
	public:
		int numberCache;
		cacheMem(int nCache);
		cacheLine *head;
		cacheLine *tail;
		bool add(uint32_t);
		bool checkValidation(uint32_t);
		bool remove(uint32_t);
		virtual ~cacheMem();
	protected:
	private:
};

#endif // CACHEMEMORYLIST_H
