#include "Diretorio.h"
#define limite 1000
Diretorio::Diretorio()
{
	//ctor
	totalOfCaches=0;
	log.open("dirLog.txt", fstream::out);
	cacheMemVector = new cacheMem*;
	nWay=0;

}

Diretorio::~Diretorio()
{
	//dtor
	log.close();
	for(int i=0; i<totalOfCaches; i++)
		delete cacheMemVector[i];
	delete cacheMemVector;
}



/** @brief validate
  *
  * @todo: document this function
  */
bool Diretorio::validate(int numberCache, uint32_t address)
{
	nWay++;
	//cout << "validade number nWay" << nWay <<endl;
	for(int  i=0; i<totalOfCaches;i++){

		if(cacheMemVector[i]->numberCache == numberCache){

			//cout << "cacheMem acess" <<endl;
			cacheMemVector[i]->add(address);
			//cout << "cacheMem acess" <<endl;
			if(nWay<limite)
				log << "validou-se numberCacheessador " << numberCache << " endereço: " << address << endl;
			return true;
		}
	}
	//cout << "qntas vezes?" << nWay <<endl;
	add(numberCache);
	cacheMemVector[totalOfCaches-1]->add(address);
	if(nWay<limite)
		log << "validou-se numberCacheessador " << numberCache << " endereço: " << address << endl;
	return true;
}

/** @brief checkValidation
  *
  * @todo: document this function
  */
bool Diretorio::checkValidation(int numberCache, uint32_t address)
{
	nWay++;
	for(int i=0; i<totalOfCaches;i++)
		if(cacheMemVector[i]->checkValidation(address))
		{
			if(nWay<limite)
				log << "Checagem do numberCacheessador: " << i << " endereço: " << address << " é Valido" <<endl;
			return true;
		}
	if(nWay<limite)
		log << "Checagem do numberCacheessador: " << numberCache << " endereço: " << address << " é Invalido" <<endl;
	return false;
}
bool Diretorio::unvalidate(int numberCache, uint32_t address)
{
	nWay++;
	for(int i=0; i<totalOfCaches;i++)
		if(cacheMemVector[i]->numberCache != numberCache)
		{
			cacheMemVector[i]->remove(address);
			if(nWay<limite)
				log << "posicao vetor invalidado da cache: " << i << " endereço: " << address << endl;
		}
	return true;
}

/** @brief remove
  *
  * @todo: document this function
  */


/** @brief add
  *
  * @todo: document this function
  */
void Diretorio::add(int numberCache)
{
	cacheMemVector[totalOfCaches] = new cacheMem(numberCache);
	totalOfCaches++;
	return;
}

