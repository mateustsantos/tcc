#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdint.h>
#include "string.h"
#include <fstream>
#include <iostream>
using namespace std;



#endif
