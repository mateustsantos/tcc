#include "cacheMem.h"

cacheMem::cacheMem(int nCache)
{
	//ctor
	numberCache = nCache;
	head = 0;

}

cacheMem::~cacheMem()
{
	//dtor
	cout << "destrutor" <<endl;
	cacheLine* aux;
	if(head!=0)
		while(head != 0 && head!=tail)
		{
			aux=tail;
			tail=tail->previous;
			tail->next=0;
			delete aux;
		}
	if(head!=0)
		delete head;

}
/** @brief ~cacheMem
  *
  * @todo: document this function
  */


/** @brief unvalidate
  *
  * @todo: document this function
  */
bool cacheMem::remove(uint32_t address)
{
	cacheLine* aux;
	aux=head;
	if(head->next == 0)
	{
		if(head->address == address){
			delete head;
			head=tail=0;
			return true;
		}
		else
		{
			return true;
		}
	}
	while(aux->next != 0)
	{
		if(aux->address == address)
		{
			cacheLine *auxPrevious, *auxNext;
			auxPrevious=aux->previous;
			auxNext= aux->next;
			auxPrevious->next = auxNext;
			auxNext->previous = auxPrevious;
			delete aux;
			return true;
		}
	}
	if(tail->address == address)
		{
			aux=tail;
			tail=tail->previous;
			tail->next=0;
			delete aux;
			return true;
		}
	return true;

}


/** @brief checkValidation
  *
  * @todo: document this function
  */
bool cacheMem::checkValidation(uint32_t address)
{
	cacheLine *aux;
	aux=head;
	if(head==0)
		return false;
	//cout << "cacheMEM 1"<<endl;
	while(aux!= 0 && (aux->previous == 0 || aux->next!=0))
	{
		//cout << "cacheMEM 2"<<endl;
		if(aux->address == address)
			return true;
		//cout << "cacheMEM 3"<<endl;
		aux=aux->next;
	}
	//cout << "cacheMEM 4"<<endl;
	if(aux == 0)
		return false;
	//cout << "cacheMEM 5"<<endl;
	if(aux->address == address)
		return true;
	//cout << "cacheMEM 6"<<endl;
	return false;

}

/** @brief remove
  *
  * @todo: document this function
  */


/** @brief add
  *
  * @todo: document this function
  */
bool cacheMem::add(uint32_t address)
{
	cacheLine *aux=head;

	//cout << "cacheMem ADD BEFORE HEAD ==0" <<endl;
	if(head==0)
	{
		head = tail = new cacheLine(address);
		return true;
	}
	//cout << "cacheMem ADD AFTER HEAD ==0" <<endl;
	if(!(checkValidation(address)))
	{
		//cout << "cacheMem ADD AFTER CHECK" <<endl;
		aux = new cacheLine(address);
		aux->previous = tail;
		tail->next = aux;
		tail=aux;
		return true;
	}
	return true;
}

/** @brief cacheMem
  *
  * @todo: document this function
  */


